﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextRPG2
{
    public class Player : Unit
    {
        // 생성자
        public Player() { }

        // 소멸자
        ~Player() { }
    }
}
