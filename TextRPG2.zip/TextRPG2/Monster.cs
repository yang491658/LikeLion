﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextRPG2
{
    public class Monster : Unit
    {
        // 생성자
        public Monster() { }

        // 소멸자
        ~Monster() { }
    }
}
